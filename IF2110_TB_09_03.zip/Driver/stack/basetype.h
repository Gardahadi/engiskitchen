
#include "mesinkata.h" //Mesin kata untuk tipe kata dan mesin kata untuk pembacaan file


#ifndef BASETYPE_H
#define BASETYPE_H


//Tipe bentukan food
typedef struct {
  Kata Nama; //nama food
  long Harga; //harga food
} FOOD;

typedef struct {
  Kata Name; //nama food yang diorder
}BAHAN;

#endif
