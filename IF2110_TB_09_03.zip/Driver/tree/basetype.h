//File definisi dasar berbagai tipe bentukan
//Tipe bentukan semuanya dibutuhkan untuk proses di restoran
//Library

#include "mesinkata.h"

#ifndef BASETYPE_H
#define BASETYPE_H

//Tipe bentukan resep
typedef struct {
	Kata Name;
} RESEP;

#endif
