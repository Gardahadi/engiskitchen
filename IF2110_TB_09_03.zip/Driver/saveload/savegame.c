#include "restoran.h"

void Save(){
    //Start file output interaction
    //Save nomor simulasi
    SaveNomorSimulasi();
    SaveTime();
    SavePlayerData();
    SaveRestoran();


}
void SaveNomorSimulasi(){

}
void SaveTime(){


}

void SavePlayerData(){
    //Save money
    //Save life
    //Save posisi
    //Save Hand
    SaveHand();


}

void SaveHand(){
    //Save number of bahan in stack
    //Save all bahan -> item in bottom of stack is written first
}

void SaveRestoran(){
    //Save resep
    SaveResep();
    //Save tick
    //Save TRAY
    SaveTray();
    //Save customer Queue
    SaveCustomerQueue();
    //Save array of order
    SaveOrder();
    //Save table data
    SaveTable();

}

void SaveResep(){

}

void SaveTray(){

}

void SaveCustomerQueue(){

}

void SaveOrder(){

}

void SaveTable(){

}

int main(){


    
}
