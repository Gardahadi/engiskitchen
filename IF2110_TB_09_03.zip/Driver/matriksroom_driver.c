#include <stdio.h>
#include "../ADT Header/matriksroom.h"

int main() {
  MATRIKS TMat;
  BacaMATRIKS(&TMat,3,3);
  TulisMATRIKS(TMat);
}
