//File definisi dasar berbagai tipe bentukan
//Tipe bentukan semuanya dibutuhkan untuk proses di restoran
//Library
#include "boolean.h" //Boolean
#include "stdio.h"
#include "stdlib.h"


//Tipe bentukan customer 
typedef struct {
  int Jumlah; //jumlah customer
  int Kesabaran; //tingkat kesabaran
  boolean IsStar; //true jika star customer
} Customer;



